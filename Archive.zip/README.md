# erlc
Basic discord bot allowing for compatibility to ERLC via API.

## Tutorial
The following youtube video has detailed instructions on what to change in your files so that the bot runs smoothly. Direct any concerns to our discord.  
[Youtube video ](https://www.youtube.com/watch?v=eoLE-LehRg8&ab_channel=SFRP)   
[Discord](https://www.youtube.com/watch?v=eoLE-LehRg8&ab_channel=SFRP)  
